package com.tdt.unicom.test;
import java.io.OutputStream;
import java.net.Socket;
import org.apache.xerces.impl.dv.util.Base64;


/**
 * 
 * @author Tank
 *
 *3.3通信节点编号规则
	在整个网关系统中，所有的通信节点(SMG、GNS、SP和SMSC)都有一个唯一的数字编号，不同的SP或SMSC或SMG或GNS编号不能相同，编号由系统管理人员负责分配。编号规则如下：
	SMG的编号规则：1AAAAX
	SMSC的编号规则：	2AAAAX
	SP的编号规则：3AAAAQQQQQ
	GNS的编号规则：4AAAAX
	其中, AAAA表示四位长途区号(不足四位的长途区号，左对齐，右补零),X表示1位序号,QQQQQ表示5位企业代码。
	
	
	<unicomconf>
		<ipaddr>127.0.0.1</ipaddr>
		<addrport>8802</addrport>
		<spNodeid>3053141211</spNodeid>
		<spListenPort>8081</spListenPort>
		<spUserName>10628365</spUserName>
		<spPassword>10628365</spPassword>
		<smgUserName>10628365</smgUserName>
		<smgPassword>10628365</smgPassword>
	</unicomconf>
 */
public class TestSendSms {
	
	public static void main(String[] args) throws Exception {
			String phoneNumber ="13014862330";  //重庆联通18523019931(不用这个接口了)    广西联通18607717225   我的13014862330
			String spNumber="10655827";//SP的接入号码，字符   重庆联通1065586304(不用这个接口了)  广西联通10655827
			String servcieType="9059066900";//ServiceType	业务代码，由SP定义，字符
			String linkId = "MOODDDS";
			String messageContent ="hello w" +
					"orld!!";
			char reportFlag ='1';
			String xmlbody = "{<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
					+ "<gwsmip>\n" + "  <message_header>\n"
					+ "    <command_id>0x3</command_id>\n"
					+ "    <sequence_number/>\n" + "  </message_header>\n"
					+ "  <message_body>\n" + "    <pk_total>1</pk_total>\n"
					+ "    <pk_number>1</pk_number>\n" + "    <user_numbers>\n"
					+ "       <user_number>"+phoneNumber+"</user_number>\n"
					+ "    </user_numbers>\n"
					+ "    <sp_number>"+spNumber+"</sp_number>\n"
					+ "    <service_type>"+servcieType+"</service_type>\n"
					+ "    <link_id>"+linkId+"</link_id>\n"
					+ "    <message_content>" + Base64.encode(messageContent.getBytes())
					+ "</message_content>\n"
					+ "    <report_flag>"+reportFlag+"</report_flag>\n"
					+ "   </message_body>\n" + "</gwsmip>\n}";
			//Socket socket = new Socket("119.254.84.182", 8806);//8805重庆  8806广西
			Socket socket = new Socket("127.0.0.1", 8805);//8805重庆  8806广西
			OutputStream out = socket.getOutputStream();
			for (int i =0 ; i < 1; i ++) { //1
				out.write(xmlbody.getBytes());
				out.flush();
			}
			out.close();
			socket.close();
	}
}
